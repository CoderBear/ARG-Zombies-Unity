static var testEnemyName : String = "TickMan";
static var testBool	: boolean = false;