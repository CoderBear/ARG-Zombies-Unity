class Condition{
	
	function Condition(){
	}
	
}