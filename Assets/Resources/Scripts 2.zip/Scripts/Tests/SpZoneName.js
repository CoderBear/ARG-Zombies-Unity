
function Start() {
	guiText.material.color = Color.black;
}

function Update () {
	guiText.text = Global.sZoneNameToDisplay;
}